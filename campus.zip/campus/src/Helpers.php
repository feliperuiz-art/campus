
<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/MoodleWS.php';

function log_msg(string $message): void {
  if (!ENABLE_LOG) return;
  $line = '[' . date('Y-m-d H:i:s') . '] ' . $message . PHP_EOL;
  @file_put_contents(LOG_FILE, $line, FILE_APPEND);
}

function computeTimeEnd(string $fechaYmd): int {
  try {
    $dt = new DateTime($fechaYmd);
  } catch (Throwable $e) {
    return 0;
  }
  // Jueves anterior a Fecha_fin, 19:00
  // Si Fecha_fin es jueves, usamos el jueves de la semana anterior
  $w = (int)$dt->format('w'); // 0=Dom, 4=Jue
  if ($w == 4) { // jueves
    $dt->modify('-7 days');
  } else {
    $dt->modify('last Thursday');
  }
  $dt->setTime(19, 0, 0);
  return $dt->getTimestamp();
} catch (Throwable $e) {
    // Si la fecha está vacía o mal, no poner fin (0)
    return 0;
  }
  $dt->modify('last Friday');
  $dt->setTime(19, 0, 0);
  return $dt->getTimestamp();
}

function spanishMonthName(int $month): string {
  $map = [1=>'ENERO',2=>'FEBRERO',3=>'MARZO',4=>'ABRIL',5=>'MAYO',6=>'JUNIO',7=>'JULIO',8=>'AGOSTO',9=>'SEPTIEMBRE',10=>'OCTUBRE',11=>'NOVIEMBRE',12=>'DICIEMBRE'];
  return $map[$month] ?? (string)$month;
}

// ==== Moodle primitives ====

function ensureUser(MoodleWS $ws, string $username, string $email, string $firstname, string $lastname, int $idnumber = 0): int {
  $found = $ws->call('core_user_get_users_by_field', [
    'field' => 'username',
    'values[0]' => $username
  ]);
  if (is_array($found) && count($found) > 0) {
    return (int)$found[0]['id'];
  }
  $params = [
    'users[0][username]' => $username,
    'users[0][email]' => $email,
    'users[0][firstname]' => $firstname,
    'users[0][lastname]' => $lastname,
    'users[0][auth]' => 'manual',
    'users[0][idnumber]' => (string)$idnumber,
    'users[0][lang]' => 'es',
    'users[0][createpassword]' => 1
  ];
  $res = $ws->call('core_user_create_users', $params);
  return (int)$res[0]['id'];
}

function resolveCourseIdByShortname(MoodleWS $ws, string $shortname): int {
  $res = $ws->call('core_course_get_courses_by_field', [
    'field' => 'shortname',
    'value' => $shortname
  ]);
  if (!empty($res['courses']) && isset($res['courses'][0]['id'])) {
    return (int)$res['courses'][0]['id'];
  }
  throw new RuntimeException("Curso no encontrado (shortname='{$shortname}')");
}

function ensureEnrol(MoodleWS $ws, int $userId, int $courseId, int $timeend = 0): void {
  $params = [
    'enrolments[0][roleid]' => 5,
    'enrolments[0][userid]' => $userId,
    'enrolments[0][courseid]' => $courseId,
    'enrolments[0][timestart]' => time(),
    'enrolments[0][timeend]' => $timeend,
    'enrolments[0][suspend]' => 0
  ];
  $ws->call('enrol_manual_enrol_users', $params);
}

function ensureCohortByIdnumber(MoodleWS $ws, int $userId, string $cohortIdnumber): void {
  // Intento typed (idnumber)
  try {
    $ws->call('core_cohort_add_cohort_members', [
      'members[0][cohorttype][type]' => 'idnumber',
      'members[0][cohorttype][value]' => $cohortIdnumber,
      'members[0][usertype][type]' => 'id',
      'members[0][usertype][value]' => $userId,
    ]);
    return;
  } catch (Throwable $e) {
    // Fallback: buscar por API y añadir con cohortid
    $res = $ws->call('core_cohort_search_cohorts', [
      'query' => $cohortIdnumber,
      'contextid' => 1,
      'includes' => 'parents'
    ]);
    $cohortId = 0;
    if (!empty($res['cohorts'])) {
      foreach ($res['cohorts'] as $c) {
        if (!empty($c['idnumber']) && $c['idnumber'] === $cohortIdnumber) {
          $cohortId = (int)$c['id']; break;
        }
      }
    }
    if ($cohortId <= 0) throw new RuntimeException("Cohorte no encontrada por idnumber: {$cohortIdnumber}");
    $ws->call('core_cohort_add_cohort_members', [
      'members[0][cohortid]' => $cohortId,
      'members[0][userid]' => $userId,
    ]);
  }
}

function findCourseGroups(MoodleWS $ws, int $courseId): array {
  $res = $ws->call('core_group_get_course_groups', ['courseid' => $courseId]);
  // Devuelve array de grupos con keys id, name, idnumber, ...
  $byIdnumber = [];
  $byName = [];
  foreach (($res ?? []) as $g) {
    if (isset($g['idnumber'])) $byIdnumber[$g['idnumber']] = $g;
    if (isset($g['name'])) $byName[$g['name']] = $g;
  }
  return ['byIdnumber' => $byIdnumber, 'byName' => $byName];
}

function ensureCourseGroup(MoodleWS $ws, int $courseId, string $name, string $idnumber = ''): int {
  $lists = findCourseGroups($ws, $courseId);
  if ($idnumber && isset($lists['byIdnumber'][$idnumber])) {
    return (int)$lists['byIdnumber'][$idnumber]['id'];
  }
  if (isset($lists['byName'][$name])) {
    return (int)$lists['byName'][$name]['id'];
  }
  // Crear
  $res = $ws->call('core_group_create_groups', [
    'groups[0][courseid]' => $courseId,
    'groups[0][name]' => $name,
    'groups[0][idnumber]' => $idnumber,
  ]);
  // Respuesta: array de IDs creados
  return (int)$res[0]['id'];
}

function addUserToGroup(MoodleWS $ws, int $groupId, int $userId): void {
  $ws->call('core_group_add_group_members', [
    'members[0][groupid]' => $groupId,
    'members[0][userid]' => $userId
  ]);
}

// ==== CRM helpers ====

function getAlumno(mysqli $conn, int $idAlumno): ?array {
  $sql = "SELECT Nombre, Apellidos, DNI, Tlf, Email FROM Alumnos WHERE ID = ?";
  $stmt = $conn->prepare($sql);
  $stmt->bind_param('i', $idAlumno);
  $stmt->execute();
  $res = $stmt->get_result();
  $row = $res->fetch_assoc();
  $stmt->close();
  return $row ?: null;
}

/**
 * Devuelve array de titulaciones del alumno para el curso dado:
 *  [ ['nombre' => shortname, 'descripcion' => desc], ... ]
 * Aplica la regla PACK4X1 si hay alguna titulación de SIA/SIACAN/SIAMAD y más de una.
 */
function getTitulacionesForAlumno(mysqli $conn, int $idCurso, int $idAlumno, bool $soloAula = false): array {
  $sql = "SELECT a.ID_alumno, a.ID_titulacion, t.Nombre, t.Descripcion, t.Por_aula
          FROM Alumnos_titulaciones a
          INNER JOIN Titulaciones t ON a.ID_titulacion = t.ID
          WHERE a.ID_curso = ? AND a.ID_alumno = ?";
  if ($soloAula) $sql .= " AND t.Por_aula = 1";
  $stmt = $conn->prepare($sql);
  $stmt->bind_param('ii', $idCurso, $idAlumno);
  $stmt->execute();
  $res = $stmt->get_result();

  $arr = [];
  while ($row = $res->fetch_assoc()) {
    $arr[$row['Nombre']] = ['nombre' => $row['Nombre'], 'descripcion' => $row['Descripcion']];
  }
  $stmt->close();

  // Regla PACK4X1
  $special = ['SIA','SIACAN','SIAMAD'];
  $hasSpecial = false;
  foreach ($special as $sp) if (isset($arr[$sp])) { $hasSpecial = true; break; }
  if ($hasSpecial && count($arr) > 1) {
    return [['nombre' => 'PACK4X1', 'descripcion' => 'PACK4X1']];
  }

  return array_values($arr);
}

/**
 * Obtiene fecha de inicio y fin del curso desde CRM, en formato Y-m-d si existen.
 * Usa COURSE_START_DATE_COLUMN y COURSE_END_DATE_COLUMN.
 */
function getCursoFechas(mysqli $conn, int $idCurso): array {
  $startCol = COURSE_START_DATE_COLUMN;
  $endCol   = COURSE_END_DATE_COLUMN;
  // Selección segura de columnas definidas en config.php
  $sql = "SELECT `$startCol` AS start_date, `$endCol` AS end_date FROM Cursos WHERE ID = ?";
  $stmt = $conn->prepare($sql);
  $stmt->bind_param('i', $idCurso);
  $stmt->execute();
  $res = $stmt->get_result();
  $row = $res->fetch_assoc();
  $stmt->close();
  $start = $row && !empty($row['start_date']) and $row['start_date'] != '0000-00-00' ? $row['start_date'] : null;
  $end   = $row && !empty($row['end_date']) and $row['end_date'] != '0000-00-00' ? $row['end_date'] : null;
  return ['start' => $start, 'end' => $end];
}


/**
 * Obtiene información del curso desde CRM: inicio (Y-m-d), fin (Y-m-d), identificador (string).
 * start = COURSE_START_DATE_COLUMN; end = COURSE_END_DATE_COLUMN; identificador = 'Identificador'.
 */
function getCursoInfo(mysqli $conn, int $idCurso): array {
  $startCol = COURSE_START_DATE_COLUMN;
  $endCol   = COURSE_END_DATE_COLUMN;
  $sql = "SELECT `$startCol` AS start_date, `$endCol` AS end_date, `Identificador` AS identificador FROM Cursos WHERE ID = ?";
  $stmt = $conn->prepare($sql);
  $stmt->bind_param('i', $idCurso);
  $stmt->execute();
  $res = $stmt->get_result();
  $row = $res->fetch_assoc();
  $stmt->close();
  $start = ($row && !empty($row['start_date']) && $row['start_date'] != '0000-00-00') ? $row['start_date'] : null;
  $end   = ($row && !empty($row['end_date'])   && $row['end_date']   != '0000-00-00') ? $row['end_date']   : null;
  $ident = ($row && !empty($row['identificador'])) ? trim($row['identificador']) : null;
  return ['start'=>$start, 'end'=>$end, 'identificador'=>$ident];
}
