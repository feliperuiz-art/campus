
<?php
class MoodleWS {
  private string $base;
  private string $token;

  public function __construct(string $baseUrl, string $token) {
    $this->base = rtrim($baseUrl, '/') . '/webservice/rest/server.php';
    $this->token = $token;
  }

  public function call(string $function, array $params = []) {
    $fields = array_merge($params, [
      'wstoken' => $this->token,
      'wsfunction' => $function,
      'moodlewsrestformat' => 'json'
    ]);

    $ch = curl_init($this->base);
    curl_setopt_array($ch, [
      CURLOPT_POST => true,
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_POSTFIELDS => http_build_query($fields),
      CURLOPT_TIMEOUT => 45,
      CURLOPT_SSL_VERIFYPEER => true,
      CURLOPT_SSL_VERIFYHOST => 2,
      CURLOPT_USERAGENT => 'moodle-ws-enrol/1.0'
    ]);
    $raw = curl_exec($ch);
    if ($raw === false) {
      $err = curl_error($ch);
      curl_close($ch);
      throw new RuntimeException('Curl error: ' . $err);
    }
    $code = curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
    curl_close($ch);

    $data = json_decode($raw, true);
    if (is_array($data) && isset($data['exception'])) {
      $msg = $data['message'] ?? 'unknown';
      $err = $data['errorcode'] ?? 'unknown';
      throw new RuntimeException("WS {$function} error ({$err}): {$msg}");
    }
    if ($code >= 400) {
      throw new RuntimeException("HTTP {$code} from WS {$function}: " . $raw);
    }
    return $data;
  }
}
