<?php
// ===== CORS (unificado) =====
$allowed_origins = [
  'https://gestion.encesap.com',
  'https://pruebas.encesap.com',
  'https://registro.globalsensos.com',
];

$origin = $_SERVER['HTTP_ORIGIN'] ?? '';
if ($origin && in_array($origin, $allowed_origins, true)) {
  header('Access-Control-Allow-Origin: ' . $origin);
  header('Vary: Origin');
}
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, X-Signature');
header('Access-Control-Allow-Credentials: true');
header('Access-Control-Max-Age: 86400');
header('Content-Type: application/json; charset=UTF-8');

// DEBUG: healthcheck sencillo en GET (quítalo cuando todo funcione)
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
  echo json_encode([
    'status' => 'ok',
    'origin' => $origin,
    'hmac_required' => (HMAC_SECRET !== ''),
    'method' => 'GET'
  ]);
  exit;
}

// Responder al preflight OPTIONS y salir
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
  http_response_code(200);
  echo json_encode(['status' => 'ok', 'method' => 'OPTIONS']);
  exit;
}

// ===== Resto de dependencias =====
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../src/Helpers.php';


function respond($status, $payload, $code=200) {
  http_response_code($code);
  echo json_encode(array_merge(['status' => $status], $payload), JSON_UNESCAPED_UNICODE);
  exit;
}

// ===== Seguridad HMAC opcional =====
// Si HMAC_SECRET está vacío en config.php, no se exige firma.
$rawBody = file_get_contents('php://input');
if (HMAC_SECRET !== '') {
  $given = $_SERVER['HTTP_X_SIGNATURE'] ?? '';
  $expect = 'sha256=' . hash_hmac('sha256', $rawBody, HMAC_SECRET);
  if (!hash_equals($expect, $given)) {
    respond('error', ['message' => 'Firma inválida'], 401);
  }
}

// ===== Parseo JSON =====
$body = json_decode($rawBody, true);
$idAlumno = isset($body['id_alumno']) ? (int)$body['id_alumno'] : 0;
$idCurso  = isset($body['id_curso'])  ? (int)$body['id_curso']  : 0;
if ($idAlumno <= 0 || $idCurso <= 0) {
  respond('error', ['message' => 'Parámetros inválidos: se requieren id_alumno y id_curso'], 400);
}

// ===== Conectar CRM =====
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
try {
  $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
  $conn->set_charset('utf8mb4');
} catch (Throwable $e) {
  respond('error', ['message' => 'Error de conexión CRM: ' . $e->getMessage()], 500);
}

// ===== Datos del alumno =====
$alumno = getAlumno($conn, $idAlumno);
if (!$alumno) {
  respond('error', ['message' => 'Alumno no encontrado'], 404);
}

$username  = strtolower($alumno['DNI']);
$firstname = strtoupper($alumno['Nombre']);
$lastname  = strtoupper($alumno['Apellidos']);
$email     = $alumno['Email'];

// ===== Info del curso (start/end/identificador) =====
$curso = getCursoInfo($conn, $idCurso);

// Fecha para nombre del grupo MES AÑO (no afecta al timestart de matrícula)
$startDateStr = $curso['start'] ?: ($curso['end'] ?: date('Y-m-d'));
$startDt = DateTime::createFromFormat('Y-m-d', $startDateStr) ?: new DateTime();

// timeend = jueves anterior a Fecha_fin a las 19:00
$timeend = 0;
if (!empty($curso['end'])) {
  $timeend = computeTimeEnd($curso['end']);
}

// ===== Titulaciones del alumno para ese curso =====
$titulaciones = getTitulacionesForAlumno($conn, $idCurso, $idAlumno, false);
if (empty($titulaciones)) {
  respond('error', ['message' => 'El alumno no tiene titulaciones para este curso'], 400);
}

// ===== Cliente WS Moodle =====
$ws = new MoodleWS(MOODLE_BASE_URL, MOODLE_TOKEN);

try {
  // Asegurar/crear usuario en Moodle
  $userId = ensureUser($ws, $username, $email, $firstname, $lastname, $idAlumno);

  $enrolledShortnames = [];
  $groupsCreated = [];
  $cohortsAdded = [];

  // Cohortes opcionales (por idnumber definidos en config.php)
  foreach (COHORT_IDNUMBERS as $cohortIdnum) {
    try {
      ensureCohortByIdnumber($ws, $userId, $cohortIdnum);
      $cohortsAdded[] = $cohortIdnum;
    } catch (Throwable $e) {
      log_msg('Cohort error ' . $cohortIdnum . ': ' . $e->getMessage());
    }
  }

  // Matricular y asignar grupos por cada titulación (shortname == Nombre)
  foreach ($titulaciones as $t) {
    $shortname = $t['nombre'];
    $courseId = resolveCourseIdByShortname($ws, $shortname);

    // Matricular (timestart=ahora, timeend calculado)
    ensureEnrol($ws, $userId, $courseId, $timeend);
    $enrolledShortnames[] = $shortname;

    // == Grupos ==
    // 1) por IDENTIFICADOR de la tabla Cursos
    if (defined('ENABLE_GROUP_BY_IDENTIFICADOR') && ENABLE_GROUP_BY_IDENTIFICADOR) {
      $ident = $curso['identificador'] ?? '';
      if (!empty($ident)) {
        $gnameIdent = sprintf(GROUP_BY_IDENT_NAME_PATTERN, $ident);
        $gidnIdent  = sprintf(GROUP_BY_IDENT_IDNUMBER_PATTERN, $ident);
        $gidIdent = ensureCourseGroup($ws, $courseId, $gnameIdent, $gidnIdent);
        addUserToGroup($ws, $gidIdent, $userId);
        $groupsCreated[] = $gnameIdent;
      } else {
        log_msg('Identificador vacío para curso CRM ID ' . $idCurso);
      }
    }

    // 3) por MES AÑO (fecha inicio)
    if (ENABLE_GROUP_BY_START_MONTH) {
      $mes = (int)$startDt->format('n');
      $anio = (int)$startDt->format('Y');
      $mesES = spanishMonthName($mes); // MAYÚSCULAS
      $gname2 = sprintf(GROUP_BY_START_MONTH_NAME_PATTERN, $mesES, $anio);
      $gidn2  = sprintf(GROUP_BY_START_MONTH_IDNUMBER_PATTERN, (int)$startDt->format('m'), $anio);
      $gid2 = ensureCourseGroup($ws, $courseId, $gname2, $gidn2);
      addUserToGroup($ws, $gid2, $userId);
      $groupsCreated[] = $gname2;
    }
  }

  // Cerrar CRM
  $conn->close();

  respond('success', [
    'message'   => 'Procesado correctamente',
    'user'      => ['id' => $userId, 'username' => $username, 'email' => $email],
    'matriculas'=> $enrolledShortnames,
    'cohortes'  => $cohortsAdded,
    'grupos'    => $groupsCreated,
    'timeend'   => $timeend
  ]);
} catch (Throwable $e) {
  log_msg('Error general: ' . $e->getMessage());
  respond('error', ['message' => $e->getMessage()], 500);
}
