
# Moodle WS Enrol (PHP, sin Make)

Webhook PHP para **crear/asegurar usuario**, **matricularlo** en cursos según las titulaciones del CRM, **añadirlo a cohortes** y **meterlo en dos grupos** dentro de cada curso:
1) Grupo con el **Identificador** de la tabla **Cursos** (por ejemplo: `MA-1025-MALAGA`).
2) Grupo con el **mes y año de la fecha de inicio** del curso (por ejemplo: `OCTUBRE 2025`).

## Requisitos

- PHP 8.0+ con cURL y MySQLi.
- Un servicio externo REST en Moodle con token y **estas funciones**:  
  `core_user_get_users_by_field`, `core_user_create_users`, `core_course_get_courses_by_field`,  
  `enrol_manual_enrol_users`, `core_cohort_add_cohort_members`,  
  `core_cohort_search_cohorts`, `core_group_get_course_groups`, `core_group_create_groups`, `core_group_add_group_members`.

> **Importante**: deja que Moodle envíe el correo de creación de contraseña usando `createpassword=1` (evita contraseñas en claro).

## Instalación

1. Copia esta carpeta al servidor (por ejemplo: `/var/www/html/moodle_ws_enrol`).
2. Edita `config.php` con tus credenciales de **CRM** y **Moodle**.
3. Asegúrate de que el servicio externo del token tiene las **funciones** listadas arriba.
4. Publica `public/enrol.php` detrás de HTTPS.

## Uso

- **POST JSON** a `public/enrol.php` con cuerpo:

```json
{
  "id_alumno": 123,
  "id_curso": 456
}
```

Respuestas JSON:
- `status: "success"` + detalles
- `status: "error"` + mensaje

## Notas de mapeo

- Se asume que el **shortname** de cada curso en Moodle **coincide** con `Nombre` de la titulación en el CRM. Si tu mapeo es distinto, ajusta `getTitulacionesForAlumno(...)` o añade un mapeo adicional.
- La **fecha fin** (para `timeend` de matrícula) se toma del campo `COURSE_END_DATE_COLUMN` definido en `config.php` (por defecto `Fecha_3`) y se transforma a **jueves anterior a `Fecha_fin` a las 19:00**.
- La **fecha de inicio** para el **grupo mes-año** se toma de `COURSE_START_DATE_COLUMN` (por defecto `Fecha_1`). Si no existe o viene vacía, cae a `Fecha_3`, y si no, a la fecha actual. La **matrícula** comienza desde el momento de alta (no se fuerza una fecha de inicio específica).
- Los **cohortes** a los que añadir al usuario se configuran en `COHORT_IDNUMBERS` (array de `idnumber` de cohorte). Si vacío, no se añade a ningún cohorte.

## Seguridad

- Configura un **HMAC opcional**: si pones `HMAC_SECRET` en `config.php`, envía `X-Signature: sha256=<hex>` calculado sobre el **cuerpo crudo** del POST. Si no lo pones, no se valida.
- No expongas este endpoint sin HTTPS.
- Minimiza los logs con PII.

